#!/usr/bin/perl

#--------------------------------------------------------------------------------------------------
# early.pl by snzieg 20160316
#--------------------------------------------------------------------------------------------------

$|=1;
use strict;
use warnings;

use Data::Dumper qw/ Dumper /;
use Spreadsheet::Read;

open(DOUT, ">", "dumper.LOG");      # Falls debug, dann File anlegen
print DOUT Dumper("dumper.LOG File created");

my $INFILE = "File Early Ad Haircare_error";

print ("\nreading ".$INFILE.".xlsx\n");
my $ReadXLSX = ReadData ($INFILE.".xlsx", attr => 1) || die "Fehler: $!\n";

print DOUT Dumper($ReadXLSX);


close DOUT;
